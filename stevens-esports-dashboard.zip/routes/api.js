const express = require("express");
const router = express.Router();
const users = require("../data/users.js");
const matches = require("../data/match.js");
const gameData = require("../data/game.js");
const { ObjectID } = require("mongodb");
const { games } = require("../config/mongoCollections.js");

function checkString(str, name) {
  if (typeof str !== "string") throw `${name} must be a string.`;
  if (!str || !(str = str.trim())) throw `${name} cannot be empty.`;
}

function checkBsonID(str, name) {
  if (typeof str !== "string") throw `${name} must be a string.`;
  if (!ObjectID.isValid(str)) throw `${name} is not a valid BSON ID.`;
}

function checkDate(str, name) {
  checkString(str, name);
  const timestamp = Date.parse(str);
  if (isNaN(timestamp) === true) throw `${name} was not a valid date string.`;
}

function checkScore(num, name) {
  const score = parseInt(num);
  if (!Number.isInteger(score))
    throw `${name} must be an integer. Got ${score}`;
  if (score < 0) throw `${name} must be a non-negative integer.`;
}

function checkMatchBody(body) {
  let { team, opponent, game, date, result, teamsScore, opponentScore } = body;
  checkString(team, "Team");
  checkString(opponent, "Opponent");
  checkBsonID(game, "Game");
  checkDate(date, "Date");

  // If the match hasn't happened yet, then we can have undefined results.
  if (new Date(date) > new Date()) {
    if (result) checkString(result, "Result");
    if (teamsScore && teamsScore !== 0) checkScore(teamsScore, "Team's score");
    if (opponentScore && teamsScore !== 0)
      checkScore(opponentScore, "Opponent's score");
  } else {
    checkString(result, "Result");
    checkScore(teamsScore, "Team's score");
    checkScore(opponentScore, "Opponent's score");
  }
}

router.get("/users", async (req, res) => {
  res.json(await users.getAllUsers(true));
});

router.get("/matches", async (req, res) => {
  res.json(await matches.getAllMatches(true));
});

router.post("/users/:id/promote", async (req, res) => {
  let { id } = req.params;

  if (!id || !(id = id.trim()))
    return res.status(400).json({ error: "ID cannot be empty." });
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).json({ error: "ID was not a valid BSON id." });

  try {
    await users.setRole(id, "administrator");
  } catch (e) {
    return res.status(400).json({ error: e });
  }
  res.json({ success: true });
});

router.post("/users/:id/demote", async (req, res) => {
  let { id } = req.params;

  if (!id || !(id = id.trim()))
    return res.status(400).json({ error: "ID cannot be empty." });
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).json({ error: "ID was not a valid BSON id." });

  try {
    await users.setRole(id, "regular");
  } catch (e) {
    return res.status(400).json({ error: e });
  }
  res.json({ success: true });
});

router.post("/match", async (req, res) => {
  let { team, opponent, game, date, result, teamsScore, opponentScore } =
    req.body;

  try {
    checkMatchBody(req.body);
    const gameObj = await gameData.getGameById(game);
    if (
      !result ||
      (!teamsScore && teamsScore !== 0) ||
      (!opponentScore && opponentScore !== 0)
    ) {
      result = undefined;
      teamsScore = undefined;
      opponentScore = undefined;
    }
    res.json(
      await matches.addMatch({
        team,
        opponent,
        game,
        date,
        result,
        teamsScore,
        opponentScore,
        matchType: gameObj.title,
      })
    );
  } catch (e) {
    console.error(req.body);
    console.error(e);
    res.status(400).json({ error: e });
  }
});

router.patch("/matches/:id/update", async (req, res) => {
  let { id } = req.params;
  let { team, opponent, game, date, result, teamsScore, opponentScore } =
    req.body;

  if (!id || !(id = id.trim()))
    return res.status(400).json({ error: "ID cannot be empty." });
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).json({ error: "ID was not a valid BSON id." });

  // Error checking
  try {
    checkMatchBody(req.body);
    teamsScore = parseInt(teamsScore);
    opponentScore = parseInt(opponentScore);
    res.json(
      await matches.updateMatch(id, {
        team,
        opponent,
        game,
        date,
        result,
        teamsScore,
        opponentScore,
      })
    );
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: e });
  }
});

module.exports = router;
